{{- define "validation" }}
{{/*
No rendered templates live in here.
Instead this is used to perform some validation checks on values that dont make sense elsewhere.
*/}}

{{/* Ensure that vpcMode and apiMode values are compatible with each other */}}
{{ if and (eq .Values.global.connectivity.vpcMode "private") (eq .Values.global.controlPlane.apiMode "public") }}
{{- fail "`.Values.global.controlPlane.apiMode` cannot be 'public' if `.Values.global.connectivity.vpcMode` is set to 'private'" }}
{{ end }}

{{/* ENI mode requires pod subnets */}}
{{- if eq .Values.global.connectivity.cilium.ipamMode "eni" }}
  {{- if not .Values.global.connectivity.eniModePodSubnets }}
  {{- fail "global.connectivity.eniModePodSubnets required when using ENI IPAM mode" }}
  {{- end }}
{{- end }}

{{/* Validate minSize <= maxSize for all node pools */}}
{{- range $name, $pool := .Values.global.nodePools }}
  {{- if and $pool.minSize $pool.maxSize }}
    {{- if gt (int $pool.minSize) (int $pool.maxSize) }}
    {{- fail (printf "Node pool '%s': minSize (%d) cannot exceed maxSize (%d)" $name (int $pool.minSize) (int $pool.maxSize)) }}
    {{- end }}
  {{- end }}
{{- end }}

{{- end -}}
