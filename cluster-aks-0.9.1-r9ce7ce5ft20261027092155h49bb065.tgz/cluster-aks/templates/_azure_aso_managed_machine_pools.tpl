{{- define "azure-aso-managed-machine-pools" -}}
{{- $root := . -}}
{{- $clusterName := include "cluster-aks.resource.name" . -}}
{{- $first := true -}}
{{- range $poolName, $pool := .Values.global.nodePools | default .Values.cluster.providerIntegration.workers.defaultNodePools }}
{{- if $first }}{{- $first = false -}}{{- else }}
---
{{- end }}
apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
kind: AzureASOManagedMachinePool
metadata:
  name: {{ $clusterName }}-{{ $poolName }}
  namespace: {{ $root.Release.Namespace }}
  labels:
    {{- include "labels.common" $root | nindent 4 }}
    giantswarm.io/machine-pool: {{ $clusterName }}-{{ $poolName }}
  annotations:
    # Helm deletes AzureASOManagedMachinePools before the Cluster on uninstall. If CAPZ reconciles that deletion
    # before the Cluster is marked for deletion, it deletes the ManagedClustersAgentPool on its own, which Azure
    # rejects for the last system pool. Keeping it lets CAPI delete it together with the Cluster instead.
    "helm.sh/resource-policy": keep
spec:
  resources:
    - apiVersion: containerservice.azure.com/v1api20250801
      kind: ManagedClustersAgentPool
      metadata:
        name: {{ $clusterName }}-{{ $poolName }}
        {{- with (include "cluster-aks.aso.credentialSecretName" $root) }}
        annotations:
          serviceoperator.azure.com/credential-from: {{ . | quote }}
        {{- end }}
      spec:
        owner:
          name: {{ $clusterName }}
        azureName: {{ $poolName | quote }}
        mode: {{ $pool.mode | default "User" }}
        type: VirtualMachineScaleSets
        vmSize: {{ required (printf "vmSize is required for node pool %q" $poolName) $pool.vmSize | quote }}
        {{- with $pool.osType | default "Linux" }}
        osType: {{ . }}
        {{- end }}
        {{- with $pool.osDiskSizeGB | default 50 }}
        osDiskSizeGB: {{ . }}
        {{- end }}
        {{- with $pool.osDiskType | default "Managed" }}
        osDiskType: {{ . }}
        {{- end }}
        # Defaulting to 110 as a quick test fix until more advanced networking config lands.
        maxPods: {{ default $pool.maxPods 110 }}
        {{- with $pool.availabilityZones | default (list "1" "2" "3") }}
        availabilityZones:
          {{- toYaml . | nindent 10 }}
        {{- end }}
        nodeLabels:
          {{- merge (dict "giantswarm.io/machine-pool" (printf "%s-%s" $clusterName $poolName)) ($pool.nodeLabels | default dict) | toYaml | nindent 10 }}
        {{- with $pool.taints }}
        nodeTaints:
          {{- range . }}
          - {{ printf "%s=%s:%s" .key (.value | default "") .effect | quote }}
          {{- end }}
        {{- end }}
        enableAutoScaling: {{ $pool.enableAutoScaling | default true }}
        {{- with $pool.count }}
        count: {{ . }}
        {{- end }}
        {{- if and (hasKey $pool "minSize") (hasKey $pool "maxSize") }}
        minCount: {{ $pool.minSize | default 1 }}
        maxCount: {{ $pool.maxSize | default 2 }}
        {{- end }}
        {{- with $pool.scaleSetPriority }}
        scaleSetPriority: {{ . }}
        {{- end }}
        {{- if and (eq ($pool.scaleSetPriority | default "Regular") "Spot") $pool.spotMaxPrice }}
        spotMaxPrice: {{ $pool.spotMaxPrice }}
        {{- end }}
        {{- if include "cluster-aks.vnet.byo" $root }}
        vnetSubnetReference:
          armId: {{ $pool.subnetArmId | default $root.Values.global.connectivity.network.vnet.subnetArmId | quote }}
        {{- else }}
        vnetSubnetReference:
          group: network.azure.com
          kind: VirtualNetworksSubnet
          name: {{ include "cluster-aks.subnet.crName" $root }}
        {{- end }}
        {{- with $pool.additionalTags }}
        tags:
          {{- toYaml . | nindent 10 }}
        {{- end }}
{{- end }}
{{- end -}}
