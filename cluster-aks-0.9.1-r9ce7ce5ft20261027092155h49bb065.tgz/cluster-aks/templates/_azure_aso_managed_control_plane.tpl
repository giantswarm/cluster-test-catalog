{{- define "azure-aso-managed-control-plane" -}}
{{- $cp := .Values.global.controlPlane -}}
{{- $ps := .Values.global.providerSpecific -}}
{{- $net := .Values.global.connectivity -}}
{{- $clusterName := include "cluster-aks.resource.name" . -}}
apiVersion: infrastructure.cluster.x-k8s.io/v1beta1
kind: AzureASOManagedControlPlane
metadata:
  name: {{ $clusterName }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "labels.common" . | nindent 4 }}
    {{- with (include "cluster-aks.labels.preventDeletion" .) }}
    {{- . | nindent 4 }}
    {{- end }}
  annotations:
    "helm.sh/resource-policy": keep
spec:
  version: {{ include "cluster.component.kubernetes.version" . }}
  resources:
    - apiVersion: containerservice.azure.com/v1api20250801
      kind: ManagedCluster
      metadata:
        name: {{ $clusterName }}
        {{- with (include "cluster-aks.aso.credentialSecretName" .) }}
        annotations:
          serviceoperator.azure.com/credential-from: {{ . | quote }}
        {{- end }}
      spec:
        owner:
          name: {{ $clusterName }}
        location: {{ required "global.providerSpecific.location is required" $ps.location | quote }}
        dnsPrefix: {{ $cp.dnsPrefix | default $clusterName | quote }}
        identity:
          type: {{ $ps.controlPlaneIdentity.type }}
          {{- if and (eq $ps.controlPlaneIdentity.type "UserAssigned") $ps.controlPlaneIdentity.userAssignedIdentityResourceID }}
          userAssignedIdentities:
            - reference:
                armId: {{ $ps.controlPlaneIdentity.userAssignedIdentityResourceID | quote }}
          {{- end }}
        servicePrincipalProfile:
          clientId: msi
        sku:
          name: Base
          tier: {{ $cp.sku.tier }}
        networkProfile:
          dnsServiceIP: {{ $net.network.dnsServiceIP | quote }}
          {{- if $net.cni.managed }}
          networkPlugin: none
          {{- else }}
          networkPlugin: {{ $cp.networking.networkPlugin }}
          {{- with $cp.networking.networkPluginMode }}
          networkPluginMode: {{ . }}
          {{- end }}
          {{- $acns := $cp.networking.advancedNetworking }}
          {{- if hasKey $acns "enabled" }}
          advancedNetworking:
            enabled: {{ $acns.enabled }}
            observability:
              enabled: {{ $acns.observability.enabled }}
            security:
              enabled: {{ $acns.security.enabled }}
              {{- with $acns.security.advancedNetworkPolicies }}
              advancedNetworkPolicies: {{ . }}
              {{- end }}
          {{- end }}
          {{- with $cp.networking.networkDataplane }}
          networkDataplane: {{ . }}
          {{- end }}
          {{- with $cp.networking.networkMode }}
          networkMode: {{ . }}
          {{- end }}
          {{- with $cp.networking.networkPolicy }}
          networkPolicy: {{ . }}
          {{- end }}
          {{- end }}
          outboundType: {{ $cp.networking.outboundType }}
          {{- with (first ($net.network.services.cidrBlocks | default list)) }}
          serviceCidr: {{ . | quote }}
          {{- end }}
          {{- if eq $cp.networking.networkPlugin "kubenet" }}
          {{- with (first ($net.network.pods.cidrBlocks | default list)) }}
          podCidr: {{ . | quote }}
          {{- end }}
          {{- end }}
        oidcIssuerProfile:
          enabled: true
        securityProfile:
          workloadIdentity:
            enabled: true
        {{- if hasKey $cp.aadProfile "managed" }}
        aadProfile:
          managed: {{ $cp.aadProfile.managed }}
          adminGroupObjectIDs:
            {{- toYaml ($cp.aadProfile.adminGroupObjectIDs | default list) | nindent 12 }}
        {{- end }}
        {{- if $cp.disableLocalAccounts }}
        disableLocalAccounts: true
        {{- end }}
        operatorSpec:
          configMaps:
            oidcIssuerProfile:
              name: {{ $clusterName }}-cluster-aso-exports
              key: oidcIssuerProfile
            principalId:
              name: {{ $clusterName }}-cluster-aso-exports
              key: principalId
        {{- if $cp.disableLocalAccounts }}
          secrets:
            # ASO cannot list admin credentials on a cluster with local accounts disabled, so it must
            # write user credentials instead. The name must differ from `<cluster>-kubeconfig`, which
            # CAPZ owns: it copies this Secret there after replacing the kubelogin `exec` block with
            # an Entra token the CAPI controllers can use directly.
            userCredentials:
              name: {{ $clusterName }}-user-kubeconfig
              key: value
        {{- end }}
        {{- if or $net.apiServerAccess.enablePrivateCluster $net.apiServerAccess.authorizedIPRanges }}
        apiServerAccessProfile:
          enablePrivateCluster: {{ $net.apiServerAccess.enablePrivateCluster }}
          {{- if $net.apiServerAccess.enablePrivateCluster }}
          enablePrivateClusterPublicFQDN: {{ $net.apiServerAccess.enablePrivateClusterPublicFQDN }}
          {{- with $net.apiServerAccess.privateDNSZone }}
          privateDNSZone: {{ . | quote }}
          {{- end }}
          {{- end }}
          {{- with $net.apiServerAccess.authorizedIPRanges }}
          authorizedIPRanges:
            {{- toYaml . | nindent 12 }}
          {{- end }}
        {{- end }}
        autoUpgradeProfile:
          # The Kubernetes version is controlled by the Giant Swarm `Release`, so AKS must never
          # upgrade it on its own. Node OS upgrades are independent and never change it.
          upgradeChannel: none
          nodeOSUpgradeChannel: {{ $ps.nodeOSUpgrade.channel }}
        {{- with $ps.kubeletIdentityResourceID }}
        identityProfile:
          kubeletidentity:
            resourceReference:
              armId: {{ . | quote }}
        {{- end }}
        {{- with $cp.additionalTags }}
        tags:
          {{- toYaml . | nindent 10 }}
        {{- end }}
    {{- $maintenanceWindow := $ps.nodeOSUpgrade.maintenanceWindow }}
    {{- if $maintenanceWindow }}
    - apiVersion: containerservice.azure.com/v1api20250801
      kind: MaintenanceConfiguration
      metadata:
        name: {{ $clusterName }}-aksmanagednodeosupgradeschedule
        {{- with (include "cluster-aks.aso.credentialSecretName" .) }}
        annotations:
          serviceoperator.azure.com/credential-from: {{ . | quote }}
        {{- end }}
      spec:
        azureName: aksManagedNodeOSUpgradeSchedule
        owner:
          name: {{ $clusterName }}
        maintenanceWindow:
          durationHours: {{ $maintenanceWindow.durationHours }}
          schedule:
            {{- toYaml $maintenanceWindow.schedule | nindent 12 }}
          startTime: {{ $maintenanceWindow.startTime | quote }}
          {{- with $maintenanceWindow.utcOffset }}
          utcOffset: {{ . | quote }}
          {{- end }}
          {{- with $maintenanceWindow.startDate }}
          startDate: {{ . | quote }}
          {{- end }}
          {{- with $maintenanceWindow.notAllowedDates }}
          notAllowedDates:
            {{- range . }}
            - start: {{ .start | quote }}
              end: {{ .end | quote }}
            {{- end }}
          {{- end }}
    {{- end }}
{{- end -}}
