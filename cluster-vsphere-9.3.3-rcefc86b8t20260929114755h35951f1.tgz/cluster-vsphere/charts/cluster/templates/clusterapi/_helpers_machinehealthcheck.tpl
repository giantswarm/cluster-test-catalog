{{- define "cluster.internal.machinehealthcheck.commonspec" -}}
{{- if eq .machineType "controlPlane" }}
remediation:
  triggerIf:
    unhealthyLessThanOrEqualTo: {{ .maxUnhealthy | default "40%" | quote }}
{{- else if eq .machineType "workers" }}
remediation:
  triggerIf:
    unhealthyLessThanOrEqualTo: {{ .maxUnhealthy | default "20%" | quote }}
{{- else }}
  {{- fail "Invalid/missing machineType" }}
{{- end }}
checks:
  nodeStartupTimeoutSeconds: {{ include "cluster.durationToSeconds" (.nodeStartupTimeout | default "8m0s") }}
  unhealthyNodeConditions:
  - type: Ready
    status: Unknown
    timeoutSeconds: {{ include "cluster.durationToSeconds" (.unhealthyUnknownTimeout | default "10m0s") }}
  - type: Ready
    status: "False"
    timeoutSeconds: {{ include "cluster.durationToSeconds" (.unhealthyNotReadyTimeout | default "10m0s") }}

  {{- /* Conditions of node-problem-detector-app */}}
  {{- if .diskFullContainerdTimeout }}
  - type: DiskFullContainerd
    status: "True"
    timeoutSeconds: {{ include "cluster.durationToSeconds" .diskFullContainerdTimeout }}
  {{- end }}
  {{- if .diskFullKubeletTimeout }}
  - type: DiskFullKubelet
    status: "True"
    timeoutSeconds: {{ include "cluster.durationToSeconds" .diskFullKubeletTimeout }}
  {{- end }}
  {{- if .diskFullVarLogTimeout }}
  - type: DiskFullVarLog
    status: "True"
    timeoutSeconds: {{ include "cluster.durationToSeconds" .diskFullVarLogTimeout }}
  {{- end }}
{{- end -}}

{{- define "cluster.internal.machinehealthcheck.use-node-problem-detector" -}}
  {{- /* Check if the control plane or any node pool uses features of node-problem-detector-app and print "true" in that case, otherwise nothing (= falsy) */}}
  {{- if $.Values.providerIntegration.resourcesApi.machineHealthCheckResourceEnabled }}
    {{- $allMachineHealthCheckObjects := list }}

    {{- if and
      $.Values.providerIntegration.resourcesApi.controlPlaneResource.enabled
      (eq $.Values.providerIntegration.resourcesApi.controlPlaneResource.provider "kubeadm")
    }}
      {{- $allMachineHealthCheckObjects = append $allMachineHealthCheckObjects $.Values.global.controlPlane.machineHealthCheck }}
    {{- end }}

    {{- range $_, $nodePoolConfig := $.Values.global.nodePools | default $.Values.providerIntegration.workers.defaultNodePools }}
      {{- if $nodePoolConfig.machineHealthCheck }}
        {{- $allMachineHealthCheckObjects = append $allMachineHealthCheckObjects $nodePoolConfig.machineHealthCheck }}
      {{- end }}
    {{- end }}

    {{- range $machineHealthCheck := $allMachineHealthCheckObjects }}
      {{- if required "machineHealthCheck enabled property is required" $machineHealthCheck.enabled }}
        {{- if or $machineHealthCheck.diskFullContainerdTimeout $machineHealthCheck.diskFullKubeletTimeout $machineHealthCheck.diskFullVarLogTimeout }}
          {{- print "true" }}
          {{- break }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
