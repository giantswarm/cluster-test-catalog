{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" | trimSuffix "." -}}
{{- end -}}

{{- define "getArchitecture" -}}
{{- if eq (.architecture | default "") "arm64" -}}
arm64
{{- else -}}
amd64
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
{{- include "labels.selector" $ }}
helm.sh/chart: {{ include "chart" . | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
release.giantswarm.io/version: {{ .Values.global.release.version | trimPrefix "v" | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app: {{ include "name" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
cluster.x-k8s.io/cluster-name: {{ include "resource.default.name" . | quote }}
giantswarm.io/cluster: {{ include "resource.default.name" . | quote }}
giantswarm.io/organization: {{ required "You must provide an existing organization name in .metadata.organization" .Values.global.metadata.organization | quote }}
cluster.x-k8s.io/watch-filter: capi
{{- end -}}

{{/*
Create a name stem for resource names
When resources are created from templates by Cluster API controllers, they are given random suffixes.
Given that Kubernetes allows 63 characters for resource names, the stem is truncated to 47 characters to leave
room for such suffix.
*/}}
{{- define "resource.default.name" -}}
{{- .Values.global.metadata.name | default (.Release.Name | replace "." "-" | trunc 47 | trimSuffix "-") -}}
{{- end -}}

{{/*
Hash function based on data provided
Expects two arguments (as a `dict`) E.g.
  {{ include "hash" (dict "data" . "global" $global) }}
Where `data` is the data to has on and `global` is the top level scope.
*/}}
{{- define "hash" -}}
{{- $data := mustToJson .data | toString  }}
{{- $salt := "" }}
{{- if .global.Values.internal.hashSalt }}{{ $salt = .global.Values.internal.hashSalt}}{{end}}
{{- (printf "%s%s" $data $salt) | quote | sha1sum | trunc 8 }}
{{- end -}}

{{- define "securityContext.runAsUser" -}}
1000
{{- end -}}
{{- define "securityContext.runAsGroup" -}}
1000
{{- end -}}

{{- define "awsContainerImageRegistry" -}}
gsoci.azurecr.io
{{- end }}

{{- define "resource.default.additionalTags" -}}
{{- if .Values.global.providerSpecific.additionalResourceTags }}
{{ toYaml .Values.global.providerSpecific.additionalResourceTags }}
{{- end }}
giantswarm.io/cluster: {{ include "resource.default.name" $ }}
{{- end -}}

{{- define "template-not-implemented" }}
{{/*
This template is present to ensure the chart renders successfully, it is not actually used.
*/}}
{{- end -}}

{{/*
Set the secondary CIDR block for Pod ENIs unless it's not set or it's the same as the VPC main CIDR block.
*/}}
{{- define "secondaryCidrBlock" -}}
{{- $podsCidrBlocks := .Values.global.connectivity.network.pods.cidrBlocks | default (list) -}}
{{- if not (empty $podsCidrBlocks) -}}
  {{- $podsCidrBlock := first $podsCidrBlocks -}}
  {{- if ne $podsCidrBlock $.Values.global.connectivity.network.vpcCidr }}
secondaryCidrBlock: {{ $podsCidrBlock }}
  {{- end }}
{{- end -}}
{{- end -}}
