{{- define "karpenter-machine-pools" }}
{{- range $name, $value := .Values.global.nodePools | default .Values.cluster.providerIntegration.workers.defaultNodePools }}
{{- if eq $value.type "karpenter" }}
apiVersion: infrastructure.cluster.x-k8s.io/v1alpha1
kind: KarpenterMachinePool
metadata:
  labels:
    giantswarm.io/machine-pool: {{ include "resource.default.name" $ }}-{{ $name }}
    {{- include "labels.common" $ | nindent 4 }}
    app.kubernetes.io/version: {{ $.Chart.AppVersion | quote }}
  name: {{ include "resource.default.name" $ }}-{{ $name }}
  namespace: {{ $.Release.Namespace }}
spec:
  ec2NodeClass:
    amiFamily: AL2023
    amiSelectorTerms:
      - alias: al2023@latest
    blockDeviceMappings:
    - deviceName: /dev/xvda
      rootVolume: true
      ebs:
        volumeSize: {{ $value.rootVolumeSizeGB | default 25 | max 25 }}Gi
        volumeType: gp3
        encrypted: true
        deleteOnTermination: true
    instanceProfile: {{ include "karpenter-node-iam-role" $ }}
    metadataOptions:
      {{- /* Cilium runs in ENI IPAM mode with `firstInterfaceIndex: 1`, so pods reach IMDS one hop away */}}
      httpPutResponseHopLimit: 2
      httpTokens: "required"
    securityGroupSelectorTerms:
    - tags:
        kubernetes.io/cluster/{{ include "resource.default.name" $ }}: owned
        aws:eks:cluster-name: {{ include "resource.default.name" $ }}
    {{- range $value.additionalSecurityGroups }}
    - id: {{ .id | quote }}
    {{- end }}
    tags:
      Name: {{ include "resource.default.name" $ }}-{{ $name }}
    subnetSelectorTerms:
      {{- if not $value.subnetTags }}
      - tags:
          {{- /* CAPA sets `owned` in a managed VPC and `shared` in a bring-your-own VPC */}}
          kubernetes.io/cluster/{{ include "resource.default.name" $ }}: "*"
          {{- /*
              CAPA tags the secondary Cilium pod subnets `sigs.k8s.io/cluster-api-provider-aws/role: private`
              too, so we use a separate selector tag `giantswarm.io/role: nodes`
          */}}
          giantswarm.io/role: "nodes"
      {{- else }}
      - tags:
          {{- range $value.subnetTags }}
          {{- range $key, $val := . }}
          {{ $key | quote }}: {{ $val | quote }}
          {{- end }}
          {{- end }}
      {{- end }}
  nodePool:
    disruption:
      consolidateAfter: {{ $value.consolidateAfter | default "1h" }}
      {{- with $value.consolidationPolicy }}
      consolidationPolicy: {{ . }}
      {{- end }}
      {{- with (coalesce $value.disruptionBudgets $value.consolidationBudgets) }}
      budgets:
      {{- toYaml . | nindent 8 }}
      {{- end }}
    {{- $limits := default (dict "cpu" "1000" "memory" "1000Gi") $value.limits }}
    limits:
      cpu: {{ $limits.cpu }}
      memory: {{ $limits.memory }}
    template:
      metadata:
        {{- $nodeLabels := dict }}
        {{- range $value.customNodeLabels }}
        {{- $parts := splitList "=" . }}
        {{- if eq (len $parts) 2 }}
        {{- $_ := set $nodeLabels (index $parts 0) (index $parts 1) }}
        {{- end }}
        {{- end }}
        {{- $_ := set $nodeLabels "giantswarm.io/machine-pool" (printf "%s-%s" (include "resource.default.name" $) $name) }}
        labels:
          {{- toYaml $nodeLabels | nindent 10 }}
      spec:
        {{- with $value.expireAfter }}
        expireAfter: {{ . }}
        {{- end }}
        requirements:
        {{- range $value.requirements }}
        - key: {{ .key }}
          operator: {{ .operator }}
          values:
            {{- range .values }}
            - "{{ . }}"
            {{- end }}
        {{- else }}
        - key: karpenter.k8s.aws/instance-family
          operator: NotIn
          values:
          - t3
          - t3a
          - t2
        - key: karpenter.sh/capacity-type
          operator: In
          values:
          - spot
          - on-demand
        - key: karpenter.k8s.aws/instance-cpu
          operator: In
          values:
          - "4"
          - "8"
          - "16"
          - "32"
        - key: karpenter.k8s.aws/instance-hypervisor
          operator: In
          values:
          - nitro
        - key: kubernetes.io/arch
          operator: In
          values:
          - {{ include "getArchitecture" (dict "architecture" $value.architecture) }}
        - key: kubernetes.io/os
          operator: In
          values:
          - linux
        {{- end }}
        {{- /* EKS nodes never get a KubeadmConfig, so `node.cluster.x-k8s.io/uninitialized` is never
               applied and nothing would ever remove it. Cilium clears its own taint. */}}
        startupTaints:
        - effect: NoExecute
          key: node.cilium.io/agent-not-ready
          value: "true"
        {{- if or (eq $value.architecture "arm64") $value.customNodeTaints }}
        taints:
        {{- if eq $value.architecture "arm64" }}
        - effect: NoSchedule
          key: kubernetes.io/arch
          value: arm64
        {{- end }}
        {{- with $value.customNodeTaints }}
        {{- range . }}
        - key: {{ .key | quote }}
          effect: {{ .effect | quote }}
          {{- if .value }}
          value: {{ .value | quote }}
          {{- end }}
        {{- end }}
        {{- end }}
        {{- end }}
        terminationGracePeriod: {{ $value.terminationGracePeriod | default "30m" }}
---
{{ end }}
{{ end }}
{{- end -}}
