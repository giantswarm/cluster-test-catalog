{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
{{ include "labels.selector" . }}
app.giantswarm.io/branch: {{ .Chart.Annotations.branch | replace "#" "-" | replace "/" "-" | replace "." "-" | trunc 63 | trimSuffix "-" | quote }}
application.giantswarm.io/commit: {{ .Chart.Annotations.commit | quote }}
application.kubernetes.io/managed-by: {{ .Release.Service | quote }}
application.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
giantswarm.io/managed-by: {{ .Release.Name | quote }}
giantswarm.io/service-type: {{ .Values.serviceType }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}


{{- define "network-policies-app.konnectivityAgent.enabled" -}}
{{- if or .Values.konnectivityAgent.enabled .Values.kamaji.enabled -}}
true
{{- end -}}
{{- end -}}

{{- define "network-policies-app.konnectivityAgent.namespaces" -}}
{{- $namespaces := list -}}
{{- if .Values.konnectivityAgent.enabled -}}
{{- $namespaces = concat $namespaces .Values.konnectivityAgent.namespaces -}}
{{- end -}}
{{- if .Values.kamaji.enabled -}}
{{- $namespaces = concat $namespaces .Values.kamaji.namespaces -}}
{{- end -}}
{{- $namespaces | uniq | toYaml -}}
{{- end -}}
